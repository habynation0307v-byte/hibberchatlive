# HibberChatLive

A mobile-friendly landing page with a transparent AI chat assistant and the owner's Moxera referral link.

## Important
- The chat is an AI assistant, not a human.
- Do not promise guaranteed earnings or hide fees/conditions.
- The site is not presented as an official Moxera website.
- The Moxera referral URL is set in `public/index.html`.

## Free deployment using Cloudflare Workers
1. Create a Cloudflare account and open Workers & Pages.
2. Install Node.js on a computer if using the command line. If you only have a phone, use Cloudflare's browser dashboard if it supports uploading/connecting a Git repository; GitHub can be used to store the project.
3. Upload this project to a GitHub repository.
4. In Cloudflare, create a Worker and connect/deploy the project. The exact dashboard flow may change; for a project with `wrangler.toml`, deploy with Wrangler from a terminal:
   - `npm install -g wrangler`
   - `wrangler login`
   - from the project folder: `wrangler deploy`
5. In Cloudflare Workers AI settings, ensure Workers AI is enabled for your account and that the `AI` binding is configured for this Worker. The included `wrangler.toml` declares the binding.
6. Open the deployed `*.workers.dev` URL on your phone and test a chat message and the Moxera button.

Cloudflare plan limits and AI usage allowances can change; check the current account dashboard before relying on free usage. A custom `.com` domain usually costs money. Start with the free Workers subdomain.

## Custom domain
If you later buy `hibberchatlive.com`, add it in Cloudflare and follow the domain verification steps. Do not advertise the `.com` address until you own and configure it.
